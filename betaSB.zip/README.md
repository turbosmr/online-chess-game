# csc667-teamproject-team10

# Todo:

1. Change the name of the repo with the correct team number.

2. Invite all members to your repository.

3. When ready, initialize your repository with the initial state of your project.



### Note that the milestone folders have been moved to their branch named milestones. 
### This is to keep them off the master/production branch so they are cleaner.
